Hi {{$email}},

<br/>
Hope you are doing well.
<br/>

The <strong>{{ $date }}</strong> dollar rate is <strong>{{ $amount }}</strong>.

<br/>

Thanks
