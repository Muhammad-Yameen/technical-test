Hi <?php echo e($email); ?>,

<br/>
Hope you are doing well.
<br/>

The <strong><?php echo e($date); ?></strong> dollar rate is <strong><?php echo e($amount); ?></strong>.

<br/>

Thanks
<?php /**PATH /var/www/html/technical-test/resources/views/emails/create-payment.blade.php ENDPATH**/ ?>