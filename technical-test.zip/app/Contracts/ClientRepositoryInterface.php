<?php

namespace App\Contracts;


interface ClientRepositoryInterface
{
    public function getAll();
}
